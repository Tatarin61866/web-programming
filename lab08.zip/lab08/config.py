
SECRET_KEY = 'mykey'
